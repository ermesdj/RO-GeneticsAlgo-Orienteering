import sys
import random
import time
import math
import numpy as np
import genetic_orientation as go
#MAIN

def distance(i, j):
    c1 = i
    c2 = j
    diff = (c1[0]-c2[0], c1[1]-c2[1])
    return math.sqrt(diff[0]*diff[0]+diff[1]*diff[1])



P=np.genfromtxt("piano3.txt") #matrice delle cordinate
A=np.zeros([len(P),len(P)])

for i in range(len(P)):
    for j in range(len(P)):
        A[i][j]=(distance(P[i],P[j]))

print(A)
#A=np.genfromtxt('matr2.txt')
V=np.genfromtxt('vet3.txt')
print("------Tempi per percorso------")
print (A)
print("--------Punteggio Nodi--------")
print (V)

tmax=int(sys.argv[1])
print("-------Limite di tempo-------")
print (tmax)
N=len(V)
print("-----Applico l'algoritmo genetico al problema-----")
s=go.find_s(V)
npopolazione=100
popolazione = []

start_time = time.perf_counter()
print("-------Popolazione iniziale-------")
popolazione=go.init_population(popolazione,npopolazione,A,V,tmax)

score = []
for i in range(len(popolazione)):
    score.append(go.fitness(popolazione[i],A,V,tmax))
print("-------Punteggio Cromosomi-------")
print(score)

popolazione=go.sort_fit(popolazione,A,V,tmax)

print("-------Popolazione ordinata per punteggio-------")
print(popolazione)

print("-----Genero nuovi cromosomi tramite crossover e mutazioni-----")
for i in range(10000):
    popolazione=go.opt_pop(popolazione,npopolazione,A,V,tmax,N)
score2=[]

print("-------Popolazione ottimizzata dall'algoritmo genetico-------")
print(popolazione)
for i in range(len(popolazione)):
    score2.append(go.fitness(popolazione[i],A,V,tmax))


end_time = time.perf_counter()

print("-------Punteggio Cromosomi-------")
print(score2)

print("-------Tempo di Esecuzione-------")
print ('time:')
print (end_time - start_time)

print("-------Miglior percorso-------")
print ('Best path:')
print (popolazione[0])
print ('Punteggio:')
print (score2[0])


f = open("result.txt","w")
for i in range(len(popolazione[0])):
    f.write(str(popolazione[0][i])+" ")

f.close()
