import sys
import random
import time
import numpy as np

def fitness(cromo,A,V,tmax):
    #devo leggere il path e calcolare i pesi + sommare gli score
    dist=0
    score=0
    for x in range(len(cromo)):
        if(x<len(cromo)-1):
            dist = dist + A[cromo[x]][cromo[x+1]]
            score = score+V[cromo[x]]
        else:
            dist = dist + A[cromo[x]][cromo[0]]
            score = score+V[cromo[x]]

    if (dist<=tmax):
        return score

def sort_fit(popo,A,V,tmax):

    for i in range(1,len(popo)):
        fit=fitness(popo[i],A,V,tmax)
        #print(fit)
        j=i-1
        a=popo[i]
        while(j>=0 and fit>fitness(popo[j],A,V,tmax)):
            #print(fitj)
             popo[j+1]=popo[j]
             j-=1
        popo[j+1]=a

    return popo

def crossover(dad,mum):
    son=[]
    son.append(dad[0])
    if(len(dad)<len(mum)):
        if(len(dad)<len(mum)/2):
            crosspt=random.randint(1,len(dad)-2)
        else:
            crosspt=random.randint(1,int((len(mum)-2)/2))

        for i in range(1,crosspt+1):
            son.append(dad[i])
        for i in range((len(mum)-1-crosspt),len(mum)-1):
            son.append(mum[i])

    elif(len(mum)<len(dad)):
            if(len(mum)<len(dad)/2):
                crosspt=random.randint(1,len(mum)-2)
            else:
                crosspt=random.randint(1,int((len(dad)-2)/2))

            for i in range(1,crosspt+1):
                son.append(dad[i])
            for i in range((len(mum)-1-crosspt),len(mum)-1):
                son.append(mum[i])
    else:
        crosspt=random.randint(1,int((len(dad)-2)/2)+1)
        #print("index",int((len(dad)-2)/2))
        #print("crosspt",crosspt)
        for i in range(1,crosspt+1):
                son.append(dad[i])
        for i in range((len(mum)-1-crosspt),len(mum)-1):
                son.append(mum[i])


    son.append(mum[len(mum)-1])
    #print("padre: ",dad)
    #print("madre: ",mum)
    #print("figlio: ",son)

    son=correct_son(son)
    #print("nuovo figlio: ",son)

#    if not valid_path(son,A,V,tmax):
#        print("non valido\n")
    return son

def check_mutation(son,N):
    for x in range(N-1):
        if x not in son:
            return 0
    return 1


def mutation(son,N):
    not_mutate=1
    full=1
    bit=random.randint(1,len(son)-2)
    if(random.randint(0,20)==1):
        #print("sto mutando\n")
        while(not_mutate):
            numero=random.randint(0,N-1)
            if numero not in son:
                son[bit]=numero
                not_mutate=0
            elif(check_mutation(son,N)):
                not_mutate=0



    return son





def correct_son(son):
    n_son = []
    n_son.append(son[0])
    for x in son:
        if x not in n_son:
            n_son.append(x)

    n_son.append(son[len(son)-1])
    return n_son




def valid_path(cromo,A,V,tmax):

    dist=0
    for x in range(len(cromo)):
        if(x<len(cromo)-1):
            dist = dist + A[cromo[x]][cromo[x+1]]
        else:
            dist = dist + A[cromo[x]][cromo[0]]
    if (dist<=tmax):
        return 1


def find_s(v):

    for i in range(len(v)):
        if(v[i]==0):
            return i


def init_population(popolazione,npopolazione,A,V,tmax):
    for i in range(npopolazione):
            added=0
            cromosoma = []
            cromosoma.append(s)
            #while len(cromosoma) < N:
            #    numero = random.randint(0,N-1)
            #    if numero not in cromosoma:
            #       cromosoma.append(numero)
            while not added:
                if(valid_path(cromosoma,A,V,tmax)==1 and len(cromosoma)>1):
                    cromosoma.append(s)
                    popolazione.append(cromosoma)
                    added=1
                elif len(cromosoma)<=1:
                    while len(cromosoma) < N:
                        numero = random.randint(0,N-1)
                        if numero not in cromosoma:
                            #print(numero)
                            cromosoma.append(numero)
                        #print("elif")
                else:                                   #lo deve accorciare
                    cromosoma.pop(len(cromosoma)-1)
                    #print("elimino con pop")
    return popolazione


def opt_pop(popolazione,npopolazione,A,V,tmax,N):
    sons= []
    i=0
    while(i<npopolazione):
        son=crossover(popolazione[i],popolazione[i+1])
        son=mutation(son,N)
        sons.append(son)
        i=i+2
    for x in sons:
        if(valid_path(x,A,V,tmax)==1):
            if(fitness(x,A,V,tmax)>fitness(popolazione[len(popolazione)-1],A,V,tmax)):
                popolazione[len(popolazione)-1]=x
                popolazione=sort_fit(popolazione,A,V,tmax)
    return popolazione
